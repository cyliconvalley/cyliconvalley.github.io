
<?php get_header(); ?>
<div class="content-area loop loop-index">
	<?php get_template_part('loop','index'); ?>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>