			<div class="clear"></div>
		</div><!-- #middle -->
	</div><!-- #middle-wrap  -->

	<?php get_sidebar('foot'); ?>

	<div id="footer-wrap">
		<div id="footer">
			<?php padd_theme_credits(); ?>
		</div><!-- #footer -->
	</div><!-- #footer-wrap -->

</div><!-- #container -->
<?php wp_footer() ?>
</body>
</html>
