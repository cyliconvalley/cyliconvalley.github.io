Thank you for downloading Heliumified Reloaded WP Theme. Be sure you have downloaded the latest version of this theme at http://www.paddsolutions.com/wordpress-theme-heliumified-reloaded

Installation
============
1. Extract heliumified-reloaded.zip and upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress Admin Dashboard > Appearance > Themes and select the Heliumified Reloaded screenshot.
3. Activate Heliumified Reloaded WordPress Theme.

For more detailed installation instructions go to http://www.paddsolutions.com/wordpress-theme-heliumified-reloaded.

Support
========
If you have any problem or found some bugs upon using this WordPress theme, feel free to contact us at support@paddsolutions.com.

License Agreement
=================
The theme is released under GNU General Public License. You may use it for all your projects for free and without any restrictions but we appreciate it if you will link back to us so that others may know where to find our free WordPress themes.

Work Projects
==============
We are looking for new clients for WordPress Design and Development, get in touch with us at info@paddsolutions.com for your future projects.

